This is an example of the step by step improvements to parameterization that we followed in the tutorial.
Step1-2. Soil Moisture
Step2-3. Yields
Step3-4. Soil N
Step4-5. N2O