These are the tutorial step 1 - Step 5 command line prompts to run the DNDC_HPC version and store the results.
Normally you would utilize a command prompt and type these out at the commmand prompt line but these .bat files are meant to help automate the process for the tutorial.

The docs directory has some legacy documentation for DNDC
Library contains the necessary library files for the model to run. Particularly the default crop library parameterization.
Output is a directory that the example site is written to but it can be saved in any directory using the --output command switch
ParameterComparison is a tutorial directory for seeing parameter changes
Validation contains the dnd file , climate files, CO2 file and soil spf necessary for the site example to run