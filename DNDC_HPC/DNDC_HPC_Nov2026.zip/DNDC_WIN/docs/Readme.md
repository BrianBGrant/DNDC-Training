### DNDCgo Command Line Guide ###
---

#### What you need ####

* `DNDCgo.exe` (Windows) or `DNDCgo` (Linux)
* A `Library` folder containing `Lib_crop\Crop_Parameters.txt`
* One or more `.dnd` site files
* The climate files those site files list
* A `.spf` soil profile file, if the site uses one

---

#### Quick start ####

Open a Command Prompt in the folder holding the program.  

Run one site:  
`DNDCgo.exe --files sites\MySite.dnd --root . --output .\Result`

On Linux:  
`./DNDCgo --files sites/MySite.dnd --root . --output ./Result`

You will see progress per year:  
```
  year 1/40 (3%)  0s elapsed, ~13s left
  year 40/40 (100%)  14s elapsed, ~0s left
```

Results appear in `Result\Record\Batch\Case1-MySite\`  

The linux `/` works in both windows and linux, however `\` only works in Windows. If your path has any spaces please enclose it in quotations as such `"./spaced folder/test.dnd"`

---

#### Folder layout ####

The root folder is what you pass to `--root`. It must contain `Library`.

```
C:\MyStudy\
    DNDCgo.exe
    Library\
        Lib_crop\Crop_Parameters.txt      required by every run
        Lib_soil\
        Lib_livestock\                    only if the site has grazing
    sites\        your .dnd files
    climate\      your climate files
    soil\         your .spf files
    Result\       created for you
```

`sites`, `climate` and `soil` are conventions only. Name them what you like.

Please don't miss to include your `Library` folder and all files that your dnd outlines. 

---

#### Command line options ####

`DNDCgo.exe --help` prints the list.

`--files <path> [<path> ...]`  
One or more `.dnd` or `.json` files, separated by spaces.

`--batch <path>`  
A batch list file naming many sites. Format below.

`--root <folder>`  
The folder holding `Library`. Default `./`

`--output <folder>`  
Where results go. Created if absent. Default `./Result`

`--daily <setting>`  
Which daily CSVs to write. Default `1`
* `1` � all 15 daily files
* `0` � none. Only annual and summary files. Much faster and smaller.
* `Day_Climate,Day_SoilN` � only the named files, commas, no spaces

Names are case insensitive and tolerate suffixes, so `day_soiln` and `Day_SoilN_1.csv` both match `Day_SoilN`.  
A misspelled name stops the run and prints the valid list. It is not silently ignored.

`--to-json`  
Parses each input, writes a `.json` beside it, exits without simulating.  
Use this to see exactly what the model read from a site file.

`--help`

Give either `--files` or `--batch`. Not both, not neither.

---

#### Examples ####

Three sites at once:  
`DNDCgo.exe --files sites\A.dnd sites\B.dnd sites\C.dnd --root . --output .\Result`

Large batch, two daily files only:  
`DNDCgo.exe --batch sites\batch_list.txt --root . --output D:\Runs\2026Aug --daily Day_SoilN2O,Day_SoilClimate`

Batch with no daily output:  
`DNDCgo.exe --batch sites\batch_list.txt --root . --output D:\Runs\2026Aug --daily 0`

Inspect what was parsed, without running:  
`DNDCgo.exe --files sites\MySite.dnd --root . --to-json`

---

#### Batch list format ####

First line is the site count. One path per line after it.

```
3
C:\MyStudy\sites\SiteA.dnd
C:\MyStudy\sites\SiteB.dnd
C:\MyStudy\sites\SiteC.dnd
```

The count must match the number of paths, or the run stops and says so.  
Paths may be absolute or relative.

---

#### How stored paths are resolved ####

Site files usually contain paths from the machine they were authored on. DNDCgo tries these in
order and takes the first that exists:

1. The path exactly as written
2. Relative to the `.dnd` file itself
3. Re-anchored on `--root`, by matching the root folder name inside the stored path
4. Re-anchored on the program's own folder, dropping leading folders one at a time

Step 4 handles most stale paths. 

So put the exe in the folder that holds `climate`, `soil` and `Library`, and stale paths
usually resolve on their own. You rarely need to edit the site files.

Be aware that Linux is case sensitive, while Windows is case insensitive. That means that Windows sees `file.txt` and `File.txt` 
as the same file, while linux considers them seperate files. 

Therefore, sticking with lowercase is recommended.

---

#### Output ####

```
Result\Record\Batch\BatchSummary.csv        all sites, all years
Result\Record\Batch\Case1-<SiteName>\
        Multi_year_summary.csv              year by year crop and soil
        Multi_year_water.csv                year by year water budget
        Day_*.csv                           one per output type per year
        CropSystem\   LivestockSystem\
```

Case numbering follows batch list order. Daily files carry the year: `Day_SoilN_1.csv` is year 1.

The 15 daily files, and the valid `--daily` names:

| File | Contents |
|---|---|
| `Day_Climate` | Daily weather as read |
| `Day_SoilClimate` | Soil temperature and moisture by depth, water table, ice, snow |
| `Day_SoilWater` | Water budget: inputs, evaporation, transpiration, leaching, runoff |
| `Day_SoilN` | N pools and fluxes by depth, nitrification, denitrification, leaching |
| `Day_SoilN2O` | N2O, NO and N2 fluxes by layer |
| `Day_SoilC` | C pools (litter, humads, humus, black C, DOC) and fluxes |
| `Day_CO2` | CO2 effects on crops |
| `Day_SoilP` | P pools and fluxes |
| `Day_SoilMicrobe` | Microbial activity, CH4 production and oxidation by depth |
| `Day_FieldCrop` | Daily crop growth, biomass, N, water and stress indices |
| `Day_MultiCrop` | Per crop growth factors where crops share a field |
| `Day_FieldManage` | Management actually applied: irrigation, fertiliser, manure |
| `Day_Graze` | Grazing C and N fluxes |
| `Day_SoilBalanceC` | Daily C mass balance check |
| `Day_SoilBalanceN` | Daily N mass balance check |

For better performance, running the program with --daily 0 or just the files you need is recommended. 

---

#### Compiling ####

Skip this unless you are changing the source or a feature flag.

Requirements:
* Windows :- MinGW-w64 (`gcc`, `g++`) or llvm-mingw (`clang`, `clang++`), CMake 3.16+
* Linux :- `gcc-15`, `g++-15`, CMake 3.16+
* C++17

Run these from the `source` folder, with the compiler's `bin` folder on `PATH`.

Windows, MinGW-w64:  
`cmake --preset windows`  
`cmake --build --preset windows --clean-first`

Windows, llvm-mingw ([github.com/mstorsjo/llvm-mingw](https://github.com/mstorsjo/llvm-mingw), UCRT build):  
`cmake --preset windows-clang`  
`cmake --build --preset windows-clang --clean-first`  
This links statically, so `DNDCgo.exe` needs no compiler DLLs and runs on any Windows 10 or later machine.

Linux:  
`cmake --preset linux-release`  
`cmake --build --preset linux-release --clean-first`

Presets available: `windows`, `windows-clang`, `linux-release`, `linux-debug`. Each only offers itself on the
matching OS. \
You can also check presets available with `cmake --list-presets`.

If CMake isn't installed on Windows, Visual Studio 2022 ships one at
`C:\Program Files\Microsoft Visual Studio\2022\<edition>\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin`.

Without a preset:  
`cmake -S . -B build -DCMAKE_BUILD_TYPE=Release`  
`cmake --build build --clean-first`

The finished program goes to `exec\Release\DNDCgo.exe` (`exec\Debug` for Debug) beside the `source`
folder, **not** to `build`. Presets keep their intermediates in `build\<preset name>`; `build` holds
intermediates only and can be deleted at any time.

If rebuilding and intended changes do not appear in program, make sure to delete the build, Result, and exec folders. The program may run older builds if not properly disposed from its path. 

Release configuration is preferred for performance. Be aware that debug and release might give different outputs. Preferably, rely on the results of the release program. 

---

#### Build options ####

Passed to CMake with `-D`.

`DNDC_MANURE` � default `OFF`. Builds ManureDNDC. Also needs `MANURE` uncommented in
`Source_main.h`. Currently broken.

`DNDC_OPENLIBM` � default `ON` on Windows, `OFF` on Linux. Compiles a bundled maths library into
the program instead of using the system one. See below.

`DNDC_OUTPUT_DIR` � default empty. Exact folder for the exe. Empty means `exec\<Config>\` beside the `source` folder.

Example:  
`cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DDNDC_OUTPUT_DIR=C:\MyStudy`

---

#### Windows and Linux results differ ####

The same site file on Windows and Linux gives slightly different numbers. Expected, not a bug.

`pow`, `exp` and `log` come from the operating system, and systems differ in the last digits.
Those differences are around 1 part in 10,000,000. \
 However, DNDC is very sensitive, therefore even such a small value can cause huge number differences in the output. \

Building both with the bundled maths library fixes it:  
`cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DDNDC_OPENLIBM=ON`

That gave 98.8% byte identical output, largest difference about 0.20 for a 34 year run example. On by default on Windows,
off by default on Linux.

Unfortunately, using a bundled math library significantly reduces performance (1.8x slower). \
That is not too noticeable in a small run, however a huge problem when running thousands of .dnds.

---

#### Troubleshooting ####

**`Cannot open ...\Library\Lib_crop\Crop_Parameters.txt`**  
No `Library` folder in your root. The giveaway is a case folder under `Record\Batch\` holding
only empty `CropSystem\` and `LivestockSystem\` and no CSVs.  
Copy `Library` from a working install into the folder you passed to `--root`.

**`Cannot open <climate file>`**  
None of the four resolution steps found it.  
Put the exe in the folder holding your `climate` folder. Check the file names, including year
suffix. Check the climate file count equals `__Simulated_years` in the `.dnd`.

**`Can not open batch file: ...`**  
Wrong path to `--batch`. Quote paths with spaces.

**`Batch file ... does not start with a file count`**  
First line of a batch list must be the number of sites.

**`Unknown daily file "..."`**  
A `--daily` name is not recognised. The valid list is printed. Commas, no spaces.


**Results unchanged after rebuilding**  
You are running an old exe. The build writes to `x64\Release\`, not `build`. Check the timestamp.

**Results changed slightly and nothing was edited**  
Check whether the machine, OS or compiler changed. See the Windows and Linux section.

---
#### Keeping Libraries updated ####

Libraries the program uses:

**CLI11** \
This is a command line parser library that simplifies paths and makes it cross compatible between Windows and Linux. Also provides command line options. \
It is a single file (CLI11.hpp) that can be kept updated with source: https://github.com/CLIUtils/CLI11/releases.  

**JuliaMath/OpenLibm** \
This is the math library that keeps results consistent between Linux and Windows. Warning: It reduces performance significantly when used. \
It is a zip file that can be kept updated with source: https://github.com/JuliaMath/openlibm/releases.

**nlohmann/json** \
This enables the use of json in the program. It is a popular JSON library for C++. However, other options that cater for different preferences do exist. \
It is also a single file (json.hpp) that can be kept updated with source: https://github.com/nlohmann/json/releases. 

`->` Also please make sure to get gcc/g++ latest version (15.2.0 was the newest when writing this) with make to get this working `<-`

---
#### Top 5 hurdles/challenges ####

**1. Matching output between configurations and operating systems** \
The biggest challenge was getting the outputs to match between different configurations (release vs. debug), as well as between operating systems (Windows vs. Linux). \
It was found that variables were being read before they were set, so they were picking up garbage values from heap memory. That was fixed with a filler in the class that \
initializes any values to 0x00 (which is 0), though that makes the values consistent rather than correct, since not every read-before-write path was checked. DNDC also \
turned out to be very sensitive to floating points, so OpenLibm was used since it gives the same results across platforms. The outputs were then compared against the \
original Windows program until they lined up.

**2. Fixing the command line interface and the paths between Windows and Linux** \
There were many hardcoded paths in the program that wouldn't let it run outside the root directory, and that only worked with `D:\DNDC` (D: is an example root directory). \
This was fixed by switching to relative paths and using mainly Unix-style paths (e.g. `./DNDCgo/x64/release`), since a forward slash works with both Windows and Linux. \
CLI11 was used for the command line interface across both platforms, which was a huge help and also gave the program the ability to have command line options.

**3. Properly integrating the code in the DndcGraphics folder and other GUI integrated code that is required for the program, outside of pure GUI components** \
This was messy, and it was difficult to find everything missing from CreateInputFiles.cpp that exists outside the DndcGraphics folder. The files were scanned thoroughly \
with AI to find the gaps, and missing code was added from both CreateInputFiles and SiteParaGo until the output reflected similar results to the original Windows program. \
Then eventually DndcGraphics was dropped from the program entirely.

**4. Writing a main.cpp file that runs everything needed and removing DLL dependency** \
Since the program originally used dynamic link libraries (DLLs), it was difficult to find a main function for the program. So the main function was modelled after the \
OnBatch() function, where now the program can run on a batch file, and .dnd/.json files. Hiccups occurred along the way with removing the DLL dependency, \
however eventually it was able to run without any reliance on DLLs and GUI components.

**5. Removing MSVC and Visual Studio dependency and getting the program working with CMake and GCC/G++** \
The difficulty in this hurdle was understanding how CMake works, so there was definitely a learning curve to it. chausner/vcxproj2cmake was used to "translate" the .vcxproj into a \
CMakeLists.txt, which reduced some of the workload in switching a complex program like DNDC over to CMake. It had only switched it to a build that runs MSVC on CMake, so \
it was then ported to work with GCC, with AI used in fixing the CMakeLists.txt. Building through CMake with the same compiler every time is also what makes the output \
consistency in hurdle 1 hold up.

---
**- Maryam Sako** \
maryamsako05@gmail.com \
sakom@uwindsor.ca




###### this file was partially written with the assistance of claude AI ######