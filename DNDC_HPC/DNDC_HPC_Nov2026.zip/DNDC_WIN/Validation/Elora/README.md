# Elora

Elora Research Station, current plot 1 (`Elora.dnd`, site name `Elora_P1_history`), 2000-2023.

## Source
- Citation: management compiled from Wagner-Riddle et al. (2007), Jayasundara et al. (2006, 2007),
  Congreves et al. (2016), Sulaiman et al. (2017), Machado et al. (2020a), Tariq et al. (2024), station
  logbooks and research station records (references per year in the workbook below).
- Data owner / contact: to be confirmed
- Management records: `Elora_Management_Dec2024.xlsx` (`C:\DNDC\sites\Elora20y`): sheets
  `Summary of Agronomy New` (all plots, 2000-2024) and `Plot1_20yr_longterm` / `Plot3_20yr_longterm`.
- Data rights: Shared with permission of site owner. Do not publish without obtaining authorization first.

## Location
- Latitude, longitude: 45.45 N as entered in `Elora.dnd` (longitude not recorded here)
- Soil series / texture: loam in the .dnd (texture 4, clay 0.19, bulk density 1.26, pH 7.0, top-layer
  SOC 0.0257). `10cm-soil.spf` has 8 layers to 2 m: bulk density 1.25-1.40, SOC 2.6% in the top 15 cm
  falling to 0.1% at depth.

## Plots
`Elora.dnd` and the observations cover plots 1 and 3. The BMP plots (2 and 4) are not set up yet.

The plots were renumbered over the years. The workbook's long-term sheets trace current plot 1 back
through old plot 2* (2000-2011) and old plot 3* (2012-2014); current plot 3 goes back through old
plot 3*. Plots 1 and 3 had the same management until 2014 and differ from 2015:

| years | current plot 1 (what `Elora.dnd` models) | current plot 3 |
|-------|-------------------------------------------|----------------|
| 2000-2011 | BMP: no-till, corn-soybean-winter wheat | same |
| 2012-2014 | manure application-time experiment: fall manure, corn | same (urea + fall manure per station records) |
| 2015-2017 | corn, broadcast urea + NUI | corn, UAN + NUI injected at side-dress |
| 2018-2023 | conventional rotation: corn-soy-soy-corn-soy-soy | diverse rotation: winter wheat and cover crops |

## Period and management
- Years observed: 2000-2023; 2015-2023 is the high-confidence period.
- Plot 1 management (from `Plot1_20yr_longterm`):

| year | crop | N (kg N/ha) | tillage |
|------|------|-------------|---------|
| 2000 | corn | UAN 50 injected Jul 4 + MAP starter 7.4 | no-till |
| 2001 | soybean; winter wheat seeded Oct 2 | none | no-till |
| 2002 | winter wheat (harvest Aug 1); red clover under-seeded Apr 23 | urea 60 (30 credited from soybean) | no-till; straw removed |
| 2003 | corn (red clover killed Apr 30) | UAN 60 side-dress Jul 2 + MAP starter 6.2 | no-till |
| 2004 | soybean | none | no-till |
| 2005 | corn | urea 98 + MAP starter 6.2 | no-till |
| 2006 | soybean | none | no-till |
| 2007 | corn | urea 98 + MAP starter 6.2 | no-till |
| 2008 | corn | urea 120 + MAP starter 6.2 | not recorded; residue added |
| 2009 | corn | UAN 118 side-dress Jun 23 + MAP starter 6.2 | no-till |
| 2010 | soybean; winter barley seeded Oct 1 | none | no-till |
| 2011 | winter barley (harvest Jul 14) | urea 98 | no planting |
| 2012 | corn | fall manure 81 (Oct 19) | plough Apr 16, disc Apr 18 and with manure |
| 2013 | corn | fall manure 106 (Nov 13) | disc |
| 2014 | corn | urea 60 (Jun 27) + fall manure 107 (Nov 28) | disc |
| 2015-2017 | corn | urea + NUI 120 broadcast, incorporated at planting + starter 30 | plough and disc |
| 2018 | corn | urea 154 + MAP starter 6.2 | disc |
| 2019 | soybean | MAP/MOP blend 9.4 | plough, disc |
| 2020 | soybean | none | no-till |
| 2021 | corn | UAN 162 injected Jun 17 + starter 5 | disc |
| 2022 | soybean | none | no-till |
| 2023 | soybean | none | no-till |

- Notes from the workbook: disking 15 cm and mouldboard plough 20 cm unless stated; "injected" means
  10 cm deep, side-banded at V6; NUI = urease + nitrification inhibitor.

## Observations
| file | variables | depths | frequency | years |
|------|-----------|--------|-----------|-------|
| `obs/Elora_OBS_N2O.csv` | N2O flux, g N2O-N/ha/day | surface | daily (6,084 days with data) | 2000-2023, none in 2008 |
| `obs/Elora_OBS_CO2.csv` | NEE, ecosystem respiration, GPP, g C/m2/day | flux tower | daily | 2012-2021 |
| `obs/Elora_OBS_NH4NO3.csv` | NH4-N, NO3-N, kg N/ha | 0-15, 15-30 cm | sampling days | 0-15 cm 2000-2023, 15-30 cm 2000-2017; none in 2007, 2008, 2011 |
| `obs/Elora_OBS_soilT.csv` | soil temperature, °C | 0-5, 25, 55, 85 cm | daily | 2000-2022 with gaps (2008-2010 missing at all depths) |
| `obs/Elora_OBS_VMC.csv` | volumetric water, m3/m3 | 5, 25, 55, 85 cm | daily | 2000-2017, none 2008-2010 |
| `obs/Elora_OBS_YIELD_DM.csv` | grain yield, kg DM/ha | | yearly, by crop | 2000-2023, none in 2008 and 2011 |

Model yield is grain C / 0.45 (dry matter). Yields are compared per crop (corn 90, soybean 3, winter
wheat 2).

Soil NH4/NO3 are plot 1 only. They were checked against the workbook's `NH4 NO3` sheets and match
exactly for every date the workbook covers:

| years | workbook sheet | plot (old numbering) | conversion |
|-------|----------------|----------------------|------------|
| 2000-2010 | `NH4 NO3 2000-2017` | plot 2 | mg/kg x 2.01 |
| 2012-2014 | `NH4 NO3 2000-2017` | plot 3 | mg/kg x 2.01 |
| 2015-2017 | `NH4 NO3 2000-2017` | plot 1 (`NI_Corn`) | mg/kg x 2.01 |
| 2018 to Apr 2022 | `NH4 NO3 2018-2022` | `P1` (Conventional), 0-15 cm only | already kg N/ha |

The x 2.01 conversion is a bulk density of 1.34 g/cm3 x 15 cm, used for both depths.

## Caveats
- The observation files hold one series each, with no plot column. From 2018 plots 1 and 3 have
  different rotations, but `Elora.dnd` follows plot 1 only. Soil NH4/NO3 are confirmed to be plot 1
  (see Observations). The other files have not been checked against the workbook yet.
- Soil NH4/NO3 for 2000-2017 were converted with a bulk density of 1.34, against about 1.25 (0-15 cm)
  and 1.30 (15-30 cm) in `10cm-soil.spf`. That puts these obs about 7% (0-15 cm) and 3% (15-30 cm)
  above the model's own soil. The bulk density behind the 2018-2022 kg N/ha values is not recorded.
- Soil NH4/NO3 from May 2022 to Nov 2023 (23 dates) are not in the management workbook, and their
  source is not recorded here.
- 2015-2023 is the high-confidence period; judge model changes on it first. Earlier years are lower
  confidence.
- 2013 corn: measured 11.8 t DM/ha against a model ~3.7 t; not being chased.
- 2011-2014 records are incomplete: the summary sheet has a 2011 fall manure (129 kg N) on plot 1 with
  no date; the station records for 2012-2014 note manure was "likely" applied, following plot 2.
- The workbook gives the 2013 fall manure date as 2024-11-13 (a typo for 2013-11-13).

## Model setup notes
- `Elora.dnd` runs 1990-2023 (34 years). 1990-1999 is a spin-up of continuous corn (crop 90) with
  80 kg N/ha urea, spring and fall tillage; there are no records for these years.
- 2000-2023 follow the plot 1 records, with these differences:
  - 2000 and 2003: the MAP starter (7.4 and 6.2 kg N) is left out.
  - 2011: fall manure on Oct 19 with 176 kg N (OrgN 63 + NH4 113); the summary sheet gives 129 kg N with
    no date.
  - 2014: fall manure 88 kg N (OrgN 53 + NH4 35) against 107 in the records.
  - 2010-2011 winter barley is entered as winter wheat (crop 2).
  - 2002 red clover is the generic cover crop (crop 47), from Apr 23 2002 to Apr 30 2003.
- The two branches carry different `Elora.dnd` parameters, each calibrated on its own build:

| parameter | NitCap | master |
|-----------|--------|--------|
| N2O_Rain_Factor | 1.3 | 1.0 |
| UreaHydrolysisWaterFactor | 2.0 | 0.1 |
| 2015-2017 nitrification inhibitor | 0.9, 55 days | 1.0, 62 days |
| 2015-2017 urease inhibitor | 1.0, 21 days | 1.0, 21 days |
| corn AGResp1/2 | 0.2 / 0.0035 | 0.4 / 0.007 |
| soybean RootResp1/2 | 0.3 / 0.00525 | 0.4 / 0.007 |
| Snow_Insulation_Factor | 1.7 | 1.3 |
| Spring_Melt_N2O_F | 20 | 8 |

  The NitCap values and the sweeps behind them are in `Plans/NitCap.md` on that branch. The two snow and thaw
  values go with NitCap's `THAW_MODEL` (`Plans/SpringThaw.md` §6):
  - With 1.3 the model's 0-5 cm soil froze about 3x too hard: 158 against 47 °C·days below 0 °C (Dec-Apr), and
    72% against 36% of Jan-Feb days below -0.5 °C.
  - 1.7 gives 75 °C·days and 55%, and the Dec-Feb bias goes from -1.1 to -0.4 °C.
  - 20 restores the spring thaw N2O: Jan-Apr 14.6 against 17.3 kg N/ha measured, daily r 0.46, 15 of 21 years
    within 2x.
- CO2 from `MultiYear_AirCO2.txt`.

## Daily views (N2O, NH4, NO3, CO2)

Two views of measured against modelled daily N2O, with fertilizer dates, rain, the seasonal pattern,
yearly totals and r²/bias by period. 2015-2023 is the high-confidence period.

- **Dashboard** (claude.ai, private until shared): <https://claude.ai/artifact/SQm3TJgyhSuKESt6DiGXLj>.
  It reads three fixed files, so it does not update when the model is rerun. Regenerate them and ask
  Claude to replace the dashboard's files (columns must stay `date, obs, nitcap, master, rain_mm`):

  ```
  python3 validation/compare.py Elora --results <branch run> --label nitcap \
      --vs <master run> --vs-label master --export <dir>
  ```

- **Soil NH4 and NO3 dashboard** (claude.ai, NitCap build against the soil samples, 0-15 and
  15-30 cm): <https://claude.ai/artifact/Xht3EcUURuUnanw8NKAFXQ>. Its daily file has
  `date, rain_mm` and `<series>_obs, <series>_model` for `no3_0_15, no3_15_30, nh4_0_15, nh4_15_30`.
  For the same charts offline:
  `compare.py Elora --results <run> --label NitCap --series NH4_0-15,NH4_15-30,NO3_0-15,NO3_15-30 --report`
  (writes `daily_report.html`).

- **CO2 dashboard** (claude.ai, NitCap 7cd63c5 before and after the crop respiration calibration,
  against the flux tower, 2012-2021): <https://claude.ai/artifact/9WDX4TeGEkXNTue96vRTSA>. Daily,
  seasonal and annual Reco, GPP and NEE, with a fit table by crop. Its daily file has `date, crop` and
  `<flux>_obs, <flux>_before, <flux>_after` for `reco, gpp, nee` (g C/m2/day), built from the
  `Reco`, `GPP` and `NEE` files `compare.py` writes under `<run>/compare/`.

- **Standalone report**, any browser, no network: the same command with `--report` writes
  `<branch run>/compare/N2O_report.html`. `--vs` is optional for both; `--series` picks another
  daily series from `compare.json`.

The two runs are each build with its own branch's `Elora.dnd`, so differences mix code and input
changes. The fertilizer events and crops come from this folder's `Elora.dnd` and the first run's output.
